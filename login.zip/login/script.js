 const Signupbtn = document. getElementById ('Signupbtn');
 const Signuppop = document. getElementById ('signup');
 const Cancelbtn = document.getElementById ('Cancel');


Signupbtn. addEventListener( 'click', function(event){
    event.preventDefault();
    Signuppop.style.display = "block";
});

Cancelbtn. addEventListener ('click', function(event){
    event.preventDefault();
    Signuppop.style.display = "none";
})


function togglePassword() {
    const passwordInput = document.getElementById("Password");
    if (passwordInput.type === "password") {
      passwordInput.type = "text";
    } else {
      passwordInput.type = "password";
    }
  }